The below files need to exist in this directory
1. file named kubeconfig containing config file of kubernetes.
2. tanzu-framework-linux-amd64-vx.xx.x.x.zip downloaded from TanzuNet.
3. any other files (such as tmc etc)