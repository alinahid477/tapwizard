function helpFunction()
{
    printf "\n"
    echo "Usage:"
    echo -e "\t-b | --bind Optional. Pass value in the format such as <IP>:<PORT>. If not provided the default is 127.0.0.1:8020. eg: --bind 192.168.220.2:8080"
    echo -e "\t-h | --help"
    printf "\n"
}

bind="127.0.0.1:8020"


output=""

# read the options
TEMP=`getopt -o b:h --long bind:,help -n $0 -- "$@"`
eval set -- "$TEMP"
while true ; do
    case "$1" in
        -b | --bind )
            case "$2" in
                "" ) bind='127.0.0.1:8020'; shift 2 ;;
                * ) bind=$2;  shift 2 ;;
            esac ;;
        -h | --help ) ishelp='y'; helpFunction; break;; 
        -- ) shift; break;; 
        * ) break;;
    esac
done

if [[ $ishelp != 'y' ]]
then
    image='accordingtoali/tap-installer'
    tag='latest'
    isexists=$(docker images | grep -w baked | awk '{print $1}')
    if [[ $isexists == 'tap-installer' ]]
    then
        image='tap-installer'
        tag='baked'
    fi
    name='tap-installer'
    printf "\nDocker image name: $name:$tag\n"


    hostip=$(echo $bind | awk 'BEGIN { FS=":" } { print $1 }')
    port=$(echo $bind | awk 'BEGIN { FS=":" } { print $2 }')
    echo "bind: $hostip:$port"
    
    docker run --privileged=true -p $hostip:$port:$port -e 'CLIENTHOST='$hostip -e 'PORT='$port -it --rm -v ${PWD}/binaries:/workspace/binaries/ -v /var/run/docker.sock:/var/run/docker.sock --name $name $image:$tag 
fi
unset ishelp
